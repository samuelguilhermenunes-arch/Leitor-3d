package com.modscout

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document

/**
 * Lê uma pasta liberada pelo seletor de arquivos do sistema (SAF),
 * por exemplo através do provedor de documentos do MT Manager, e compara
 * com a leitura anterior para descobrir o que foi criado, alterado ou apagado.
 */
class SafWatcher(
    private val ctx: Context,
    private val tree: Uri,
    private val onEvent: (kind: String, path: String) -> Unit
) {
    private var prev: Map<String, Pair<Long, Long>>? = null

    private fun scan(): Map<String, Pair<Long, Long>> {
        val out = HashMap<String, Pair<Long, Long>>()
        walk(DocumentsContract.getTreeDocumentId(tree), "", out, 0)
        return out
    }

    private fun walk(docId: String, prefix: String, out: MutableMap<String, Pair<Long, Long>>, depth: Int) {
        if (depth > 10 || out.size > 20000) return
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED
        )
        try {
            ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val path = prefix + c.getString(1)
                    val size = if (c.isNull(3)) -1L else c.getLong(3)
                    val modified = if (c.isNull(4)) 0L else c.getLong(4)
                    if (c.getString(2) == Document.MIME_TYPE_DIR) walk(id, "$path/", out, depth + 1)
                    else out[path] = size to modified
                }
            }
        } catch (e: Exception) {
            onEvent("INFO", "Erro ao ler pasta: ${e.message}")
        }
    }

    fun tick() {
        val now = scan()
        val before = prev
        if (before == null) {
            onEvent("INFO", "Pasta lida: ${now.size} arquivos")
            now.keys.sorted().forEach { onEvent("EXISTE", it) }
        } else {
            for ((k, v) in now) {
                val old = before[k]
                if (old == null) onEvent("CRIOU", k) else if (old != v) onEvent("ALTEROU", k)
            }
            for (k in before.keys) if (k !in now) onEvent("APAGOU", k)
        }
        prev = now
    }
}
